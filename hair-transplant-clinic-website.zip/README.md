# Apex Hair Restoration Clinic - Static Website

A modern, high-converting, mobile-responsive, and local SEO-optimized static website for a hair transplant clinic / doctor.

Designed and architected according to clinical trust benchmarks, modern healthcare UI aesthetics, and strict local SEO best practices.

---

## 📁 File Structure

```
c:/laragon/www/static website/
├── index.html                           # Main conversion homepage
├── about.html                           # Clinic philosophy, facilities & doctor
├── hair-transplant.html                 # Comprehensive hair restoration guide
├── treatments.html                      # All treatments overview
├── before-after.html                    # Interactive before & after gallery
├── testimonials.html                    # Verified patient stories & reviews
├── faq.html                             # Expandable FAQ hub with schema
├── contact.html                         # Contact page with validated form & map
├── privacy-policy.html                  # Healthcare privacy statement
├── terms.html                           # Website terms of use
├── medical-disclaimer.html              # Medical educational notice
├── 404.html                             # Custom branded 404 error page
│
├── treatments/
│   ├── fue-hair-transplant.html         # In-depth FUE microsurgery guide
│   ├── dhi-hair-transplant.html         # In-depth DHI direct implantation guide
│   ├── beard-transplant.html            # Facial & beard restoration guide
│   ├── eyebrow-transplant.html          # Delicate eyebrow reconstruction guide
│   └── hair-loss-consultation.html      # Digital trichoscopy & scalp analysis
│
├── css/
│   ├── style.css                        # Design system tokens & core components
│   └── responsive.css                   # Multi-device breakpoints (320px to 1440px+)
│
├── js/
│   ├── main.js                          # Core configuration, sticky header, modal & validation
│   ├── menu.js                          # Accessible mobile drawer & overlay
│   ├── faq.js                           # Smooth accordion interactions
│   └── before-after.js                  # Interactive touch/drag comparison slider
│
├── images/
│   ├── doctor/                          # Doctor portraits (doctor-profile.jpg)
│   ├── clinic/                          # Facility interior & consultation photos
│   ├── treatments/                      # High-resolution clinical vector diagrams
│   ├── before-after/                    # Scalp restoration before/after cases
│   └── icons/                           # Clinic SVG branding logo & vectors
│
├── robots.txt                           # Search engine crawling rules
├── sitemap.xml                          # XML search index sitemap
└── README.md                            # Documentation & configuration guide
```

---

## 🛠️ Centralized Placeholders Guide

All clinic-specific data is standardized using clearly marked placeholders. You can replace them instantly before going live.

### Key Placeholders List:

| Placeholder | Description | Example Replacement |
| :--- | :--- | :--- |
| `[CLINIC_NAME]` | Name of the clinic | `Apex Hair Restoration Clinic` |
| `[DOCTOR_NAME]` | Medical Director / Surgeon | `Dr. Alexander Thorne` |
| `[DOCTOR_CREDENTIALS]` | Qualifications & Specialization | `MD, Board-Certified Hair Restoration Specialist` |
| `[PHONE]` | Primary telephone number | `+1 (800) 555-4247` |
| `[WHATSAPP]` | WhatsApp consultation number | `+1 (800) 555-4247` |
| `[EMAIL]` | Clinic contact email | `consult@apexclinic.example` |
| `[ADDRESS]` | Physical street address | `742 Medical Center Blvd, Suite 400` |
| `[CITY]` | Target city for local SEO | `London`, `New York`, `Dubai` |
| `[COUNTRY]` | Target country | `United Kingdom`, `USA`, `UAE` |
| `[DOMAIN]` | Live production website URL | `https://www.apexclinic.example` |
| `[GOOGLE_MAPS_URL]` | Google Maps directions link | `https://maps.google.com/?q=...` |

---

## ⚡ Fast Find & Replace via PowerShell

To quickly swap all placeholders across all HTML and JS files in one command:

```powershell
# Open PowerShell in the project directory:
cd "c:\laragon\www\static website"

# Example: Replace [CITY] with your real city
Get-ChildItem -Recurse -Include *.html,*.js,*.xml | ForEach-Object {
  (Get-Content $_.FullName) -replace '\[CITY\]', 'Manchester' | Set-Content $_.FullName
}

# Example: Replace [CLINIC_NAME]
Get-ChildItem -Recurse -Include *.html,*.js,*.xml | ForEach-Object {
  (Get-Content $_.FullName) -replace '\[CLINIC_NAME\]', 'Manchester Hair Clinic' | Set-Content $_.FullName
}
```

---

## 🌐 Running Locally & Deploying

### Option 1: Laragon (Installed)
The project is located in `c:\laragon\www\static website`.
1. Open Laragon and start Apache / Nginx.
2. Visit `http://static-website.test` (or `http://localhost/static website/index.html`) in any browser.

### Option 2: Live Server or Local Python Server
```powershell
# In PowerShell:
cd "c:\laragon\www\static website"
python -m http.server 8080
# Visit http://localhost:8080
```

### Option 3: Static Hosting Deployment
The website consists of clean, dependency-free HTML5, CSS3, and Vanilla JavaScript. It can be deployed directly to:
- **Netlify** (drag-and-drop folder or git push)
- **Vercel**
- **GitHub Pages**
- **Cloudflare Pages**
- **Traditional cPanel / Apache / Nginx web hosting**

---

## 📬 Connecting Contact Form to a Backend

Because this is a static website, the form includes complete client-side validation out of the box. To receive emails when visitors submit inquiries:

1. **Using Formspree**:
   In `index.html` and `contact.html`, add:
   ```html
   <form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
   ```
2. **Using Netlify Forms**:
   Add `netlify` to the form element:
   ```html
   <form name="contact" method="POST" data-netlify="true">
   ```

---

## 🔍 Local SEO & Schema Markup Checklist

- **MedicalBusiness / LocalBusiness JSON-LD:** Implemented on the homepage.
- **FAQPage Schema:** Implemented on `faq.html`.
- **MedicalProcedure Schema:** Implemented on each treatment page.
- **Breadcrumbs Hierarchy:** Implemented on all inner pages.
- **Canonical URLs & Open Graph:** Fully included in all `<head>` sections.
